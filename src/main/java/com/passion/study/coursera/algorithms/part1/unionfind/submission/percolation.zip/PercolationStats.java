//package com.passion.study.coursera.algorithms.part1.unionfind.submission;

public class PercolationStats {

    // perform independent trials on an n-by-n grid
    public PercolationStats(int n, int trials) {

    }

    // sample mean of percolation threshold
    public double mean() {
        return Double.MAX_VALUE;
    }

    // sample standard deviation of percolation threshold
    public double stddev() {
        return Double.MAX_VALUE;
    }

    // low endpoint of 95% confidence interval
    public double confidenceLo() {
        return Double.MAX_VALUE;
    }

    // high endpoint of 95% confidence interval
    public double confidenceHi() {
        return Double.MAX_VALUE;
    }

    // test client (see below)
    public static void main(String[] args) {

    }

}